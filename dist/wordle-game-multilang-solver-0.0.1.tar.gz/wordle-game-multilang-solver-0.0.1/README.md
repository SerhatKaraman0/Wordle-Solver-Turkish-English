<img src="https://www.nytimes.com/games/wordle/images/NYT-Wordle-Meta.png"></img>
# Wordle-English-Turkish-Solver

### Wordle spread its fame all over the world. So I code a script to make guessing process easier 

# How-Game-Works
### 🟩 -> Means letter is in word and correct place. Represent with 'g' (green) 
### 🟨 -> Means letter is in the word but wrong place. Represent with 'y' (yellow) 
### 🟥 -> Means letter not in the word. Represent with 'r' (red)
### 'e' word is to represent word not in wordle database for example if word is not available type 'eeeee' to console

# Social-Media
### https://www.reddit.com/user/s3rh4tk
### https://www.instagram.com/kernel___error/

